#!/usr/bin/python
class IP_ADDRESS():
    def __init__(self, ipaddress):
        self.ipaddress = ipaddress

    def get_ipaddress(self):
        return self.ipaddress
